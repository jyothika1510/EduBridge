package Service;

import model.Hotel;
import model.LocalTransport;
import model.Transport;

public interface AdminInterface {
    void addHotel(Hotel hotel);
    void updateHotel(int id, String location, double price);
    void deleteHotel(int id);
    Hotel selectHotel(int id);

    void addTransport(Transport transport);
    void updateTransport(int id, String type, double price);
    void deleteTransport(int id);
    Transport selectTransport(int id);

    void addLocalTransport(LocalTransport localTransport);
    void updateLocalTransport(int id, String type, double price);
    void deleteLocalTransport(int id);
    LocalTransport selectLocalTransport(int id);
}

