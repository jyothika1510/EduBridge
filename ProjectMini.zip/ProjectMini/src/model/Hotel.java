package model;

public class Hotel {
    public int id;
    public String location;
    public double price;

    public Hotel(int id, String location, double price) {
        this.id = id;
        this.location = location;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Hotel [ID=" + id + ", Location=" + location + ", Price=" + price + "]";
    }
}
