package model;

public class LocalTransport {
    public int id;
    public String type;
    public double price;

    public LocalTransport(int id, String type, double price) {
        this.id = id;
        this.type = type;
        this.price = price;
    }

    @Override
    public String toString() {
        return "LocalTransport [ID=" + id + ", Type=" + type + ", Price=" + price + "]";
    }
}

