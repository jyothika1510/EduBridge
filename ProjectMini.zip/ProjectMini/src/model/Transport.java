package model;

public class Transport {
    public int id;
    public String type;
    public double price;

    public Transport(int id, String type, double price) {
        this.id = id;
        this.type = type;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Transport [ID=" + id + ", Type=" + type + ", Price=" + price + "]";
    }
}

