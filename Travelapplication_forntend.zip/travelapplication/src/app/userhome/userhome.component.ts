import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-userhome',
  standalone: false,
  
  templateUrl: './userhome.component.html',
  styleUrl: './userhome.component.css'
})
export class UserhomeComponent implements OnInit {

  userId:any;
  user:any;
  userName:any;
  ngOnInit(): void {
    this.userId=this.activateRoute.snapshot.params['userId'];
    this.userService.getUserById(this.userId).subscribe(
      (response:any)=>
      {
        this.user=response;
        this.userName=this.user.username;
      }
    )
  }

   constructor (
      private  router: Router, private activateRoute: ActivatedRoute,private userService:UserService
    ){
      
    }
    hotel(){
      this.router.navigate(['viewhotelurl',this.userId]);//It navigates to app-routing.module.ts
     
      
    }
    
    booking(){
      this.router.navigate(['booking']);//It navigates to app-routing.module.ts
      console.log("bookings");
    }
    transport(){
      this.router.navigate(['viewtransporturl']);
      
    }
    localtransport(){
      this.router.navigate(['viewlocaltransporturl']);
    }
}
