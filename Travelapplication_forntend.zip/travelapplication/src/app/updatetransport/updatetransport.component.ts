import { Component, OnInit } from '@angular/core';
import { TransportService } from '../service/transport.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-updatetransport',
  standalone: false,
  
  templateUrl: './updatetransport.component.html',
  styleUrl: './updatetransport.component.css'
})
export class UpdatetransportComponent implements OnInit {
transportId:any;
  transport:any;
ngOnInit(): void {
this.transportId=this.activateroute.snapshot.params['transportId'];
 this.transportservice.getTransportById(this.transportId).subscribe(
  (Response:any)=>{
    console.log(Response);
    this.transport=Response;
    console.log(this.transport);
  }
 ) 
}
constructor(private activateroute:ActivatedRoute,private transportservice:TransportService,private router:Router){

}
onSubmit(){
this.transportservice.updateTransportById(this.transportId, this.transport).subscribe(
  ((Response:any)=>{
    alert("updated sucessfully");
    this.router.navigate(['transportlisturl'])
  })
)
}
Onback(){
  
}
}
