import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserViewComponent } from '../user-view/user-view.component';
import { HotelService } from '../service/hotel.service';
import { TransportService } from '../service/transport.service';
import { LocaltransportService } from '../service/localtransport.service';
describe('UserViewComponent', () => {
  let component: UserViewComponent;
  let fixture: ComponentFixture<UserViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [UserViewComponent],
      providers: [HotelService, TransportService, LocaltransportService]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fetch hotels on init', () => {
    spyOn(component, 'fetchHotels').and.callThrough();
    component.ngOnInit();
    expect(component.fetchHotels).toHaveBeenCalled();
  });

  it('should fetch transports on init', () => {
    spyOn(component, 'fetchTransports').and.callThrough();
    component.ngOnInit();
    expect(component.fetchTransports).toHaveBeenCalled();
  });

  it('should fetch local transports on init', () => {
    spyOn(component, 'fetchLocalTransports').and.callThrough();
    component.ngOnInit();
    expect(component.fetchLocalTransports).toHaveBeenCalled();
  });
});
