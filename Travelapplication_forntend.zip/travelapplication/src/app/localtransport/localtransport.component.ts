import { Component, OnInit } from '@angular/core';
import { LocaltransportService } from '../service/localtransport.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { localtransport } from '../model/localtransport';
@Component({
  selector: 'app-localtransport',
  standalone: false,
  
  templateUrl: './localtransport.component.html',
  styleUrl: './localtransport.component.css'
})
export class LocaltransportComponent implements OnInit{
userId: any;
  localtransport = new localtransport();

  constructor(
    private localtransportService: LocaltransportService, // Fixed incorrect injection syntax
    private router: Router,
    private activateRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    // Fetching the userId from route parameters
    this.userId = this.activateRoute.snapshot.params['userId'];
  }

  onBack() {
   
  }

  onSubmit() {
    console.log(this.localtransport)
    this.localtransportService.addLocalTransport(this.localtransport).subscribe(
      () => {
        alert('LocalTransport is added successfully!');
        this.router.navigate(['adminhomeurl', this.userId]);
      },
    )
  
    }
}
