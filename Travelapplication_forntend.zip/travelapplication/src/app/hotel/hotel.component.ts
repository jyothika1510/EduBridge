import { Component, OnInit } from '@angular/core';
import { Hotel } from '../model/hotel';
import { HotelService } from '../service/hotel.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-hotel',
  standalone: false,
  templateUrl: './hotel.component.html',
  styleUrls: ['./hotel.component.css'],
})
export class HotelComponent implements OnInit { 
  userId:any;

ngOnInit(): void {
  
  this.userId=this.activateRoute.snapshot.params['userId'];
}
pstatus:boolean=false;
 
  hotel = new Hotel();
  errorMessage:string=" ";
constructor(private hotelService:HotelService,private router:Router,private activateRoute:ActivatedRoute){

}
validatePrice()
{
  if(this.hotel.hotel_price_per_night<500)
  {
    this.pstatus=true;
    this.errorMessage="price should be greater than 500";
  }else
  {
    this.pstatus=false;
    this.errorMessage=" ";
  }
}
  Onback() {
    this.router.navigate(['adminhomeurl', this.userId]);
  }

 
  onSubmit() {
  //  if()
    this.hotelService.addhotel(this.hotel).subscribe(
      (response) => {
        alert("hotel is added");
       this.router.navigate(['adminhomeurl',this.userId]);
      }
    )
  }

 
}
