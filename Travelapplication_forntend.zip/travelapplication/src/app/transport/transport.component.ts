import { Component, OnInit } from '@angular/core';
import { transport } from '../model/transport';
import { TransportService } from '../service/transport.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-transport',
  standalone: false,
  templateUrl: './transport.component.html',
  styleUrls: ['./transport.component.css'] // Fixed typo from `styleUrl` to `styleUrls`
})
export class TransportComponent implements OnInit {
  userId: any;
  transport = new transport();

  constructor(
    private transportService: TransportService, // Fixed incorrect injection syntax
    private router: Router,
    private activateRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    // Fetching the userId from route parameters
    this.userId = this.activateRoute.snapshot.params['userId'];
  }

  onBack() {
   
  }

  onSubmit() {
    console.log(this.transport)
    this.transportService.addTransport(this.transport).subscribe(
      (response) => {
        alert('Transport is added successfully!');
        this.router.navigate(['adminhomeurl', this.userId]);
      },
    )
  
    }
  }

