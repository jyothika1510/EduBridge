export class Booking {
  
    booking_id: number|null;
    bookingType: string;
    bookingDate: string;
   

    constructor(
       

    )
    {
       this.booking_id = null;
       this.bookingType = "";
       this.bookingDate = "";
       
    }

}