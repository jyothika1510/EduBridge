export class localtransport{
    localtransport_id : number|null;
    localtransport_type : string;
    location:string;
    price_per_km:number;
    

    constructor(
        

    )

    
    
{
    this.localtransport_id=null;
    this.localtransport_type="";
    this.location="";
    this.price_per_km=0;
}



}