export class Payment{
    paymentId:number | null;
    price:number;
    paymentStatus:string;


constructor(

)

{
    this.paymentId=null;
    this.price=0;
    this.paymentStatus="";


}
}