export class User {
   userId:number|null;
    username:string;
    userPassword:string;
    phone:string;
    emailId:string;
    city:string;
    role:String;

    constructor(
      /* userId:,
        username:string,
        userPassword:string,
        phone:string,
        emailId:string,
        city:string,
        role:string,*/
    )
  {
      this.userId=null;
        this.username="";
        this.userPassword="";
        this.phone="";
        this.emailId="";
        this.city="";
        this.role="";
    }


}