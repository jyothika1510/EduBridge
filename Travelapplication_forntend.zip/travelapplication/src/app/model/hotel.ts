export class Hotel {
  
     hotelId: number|null;
     hotel_name: string;
     hotelLocation: string;
     hotel_price_per_night: number;
     hotel_rating: string;
     hotel_review: string;
     petFriendly?: boolean 

     constructor(
        

     )
     {
        this.hotelId = null;
        this.hotel_name = "";
        this.hotelLocation = "";
        this.hotel_price_per_night = 0;
        this.hotel_rating = "";
        this.hotel_review = "";
        this.petFriendly = false;
     }
 
}