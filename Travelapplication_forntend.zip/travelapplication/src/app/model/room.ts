export class Room{
    roomId : number | null;
    roomNumber : string;
    roomType : string;
    price : number;
    isAvailable : boolean;
    checkInDate:Date;
    checkOutDate:Date;


    constructor(


    )

    {
        this.roomId=null;
        this.roomNumber="";
        this.roomType="";
        this.price=0;
        this.isAvailable=true;
        this.checkInDate=new Date;
        this.checkOutDate=new Date;

    }



}