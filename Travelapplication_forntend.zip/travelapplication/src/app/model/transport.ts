export class transport{
    transport_id : number|null;
    source : string;
    transport_type:string;
    destination:string;
    price:number;
   

    constructor(
        

    )

    
    
{
    this.transport_id=null;
    this.source="";
    this.transport_type="";
    this.destination="";
    this.price=0;
    
}



}