import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeComponent } from './welcome/welcome.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { BookingComponent } from './booking/booking.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { HotelComponent } from './hotel/hotel.component';
import { HotellistComponent } from './hotellist/hotellist.component';
import { UpdatehotelComponent } from './updatehotel/updatehotel.component';
import { transport } from './model/transport';
import { TransportComponent } from './transport/transport.component';
import { TransportlistComponent } from './transportlist/transportlist.component';
import { UpdatetransportComponent } from './updatetransport/updatetransport.component';
import { localtransport } from './model/localtransport';
import { LocaltransportlistComponent } from './localtransportlist/localtransportlist.component';
import { LocaltransportComponent } from './localtransport/localtransport.component';
import { UpdatelocaltransportComponent } from './updatelocaltransport/updatelocaltransport.component';
import { ViewhotelComponent } from './viewhotel/viewhotel.component';
import { ViewtransportComponent } from './viewtransport/viewtransport.component';
import { ViewlocaltransportComponent } from './viewlocaltransport/viewlocaltransport.component';
import { AddroomComponent } from './addroom/addroom.component';
import { RoomlistComponent } from './roomlist/roomlist.component';
import { ViewroomComponent } from './viewroom/viewroom.component';
import { PaymentComponent } from './payment/payment.component';



const routes: Routes = [{path:"",component:WelcomeComponent},
  {path:"usersigninUrl",component:LoginComponent},
  {path:"usersignupUrl",component:SignupComponent},
  {path:"booking",component:BookingComponent},
  {path:"userhomeurl/:userId",component:UserhomeComponent},
{path:"adminhomeurl/:userId",component:AdminhomeComponent},
{path:"hotel/:userId",component:HotelComponent},
//{path:"hotellisturl/:userId",component:HotellistComponent},
{path:"hotellisturl",component:HotellistComponent},                                   
{path:"updatehotelurl/:hotelId",component:UpdatehotelComponent},
{path:"transport/:userId",component:TransportComponent},
{path:"transportlisturl",component:TransportlistComponent},
{path:"updatetransporturl/:transportId",component:UpdatetransportComponent},
{path:"localtransport/:userId",component:LocaltransportComponent},
{path:"localtransportlisturl",component:LocaltransportlistComponent},
{path:"updatelocaltransporturl/:localtransportId",component:UpdatelocaltransportComponent},
{path:"viewhotelurl/:userId",component:ViewhotelComponent},
{path:"viewtransporturl",component:ViewtransportComponent},
{path:"viewlocaltransporturl",component:ViewlocaltransportComponent},
{path:"booking",component:BookingComponent},
{path:"addroomurl/:hotelId",component:AddroomComponent},
{path:"roomlisturl/:hotelId",component:RoomlistComponent},
{path:"viewroom/:hotelId",component:ViewroomComponent},
{path:"paymenturl",component:PaymentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
