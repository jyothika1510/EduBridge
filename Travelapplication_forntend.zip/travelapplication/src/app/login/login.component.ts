import { Component } from '@angular/core';
import { User } from '../model/user';
import { UserService } from '../service/user.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  standalone: false,
  
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
 user = new User();
 userId:any;
 constructor(private userService:UserService,private router:Router){

 }
  Onback(){

  }
  onSubmit(){
this.userService.userSignIn(this.user).subscribe(
  (Response:any)=>
  {
    if(Response!=null){
      this.userId=Response.userId;
      sessionStorage.setItem('userId',this.userId);
      if(Response.role=='USER'){
    alert("user signin sucess");
  this.router.navigate(['userhomeurl',this.userId]);
      }else if(Response.role=='ADMIN')
      {
        alert("admin signin sucess");
  this.router.navigate(['adminhomeurl',this.userId]);
      }
}
    else
    alert("user not found");
  }
)
  }
}
