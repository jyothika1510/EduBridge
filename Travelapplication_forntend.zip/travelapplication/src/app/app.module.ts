import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SignupComponent } from './signup/signup.component';
import { BookingComponent } from './booking/booking.component';
import { HotelComponent } from './hotel/hotel.component';
import { HeaderComponent } from './header/header.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { HotellistComponent } from './hotellist/hotellist.component';
import { UpdatehotelComponent } from './updatehotel/updatehotel.component';
import { TransportComponent } from './transport/transport.component';
import { TransportlistComponent } from './transportlist/transportlist.component';
import { UpdatetransportComponent } from './updatetransport/updatetransport.component';
import { LocaltransportComponent } from './localtransport/localtransport.component';
import { LocaltransportlistComponent } from './localtransportlist/localtransportlist.component';
import { UpdatelocaltransportComponent } from './updatelocaltransport/updatelocaltransport.component';
import { ViewhotelComponent } from './viewhotel/viewhotel.component';
import { ViewtransportComponent } from './viewtransport/viewtransport.component';
import { ViewlocaltransportComponent } from './viewlocaltransport/viewlocaltransport.component';
import { AddroomComponent } from './addroom/addroom.component';
import { RoomlistComponent } from './roomlist/roomlist.component';
import { ViewroomComponent } from './viewroom/viewroom.component';
import { PaymentComponent } from './payment/payment.component';


@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    LoginComponent,
    SignupComponent,
    BookingComponent,
    HotelComponent,
    HeaderComponent,
    UserhomeComponent,
    AdminhomeComponent,
    HotellistComponent,
    UpdatehotelComponent,
    TransportlistComponent,
    UpdatetransportComponent,
    TransportComponent,
    LocaltransportComponent,
    LocaltransportlistComponent,
    UpdatelocaltransportComponent,
    ViewhotelComponent,
    ViewtransportComponent,
    ViewlocaltransportComponent,
    AddroomComponent,
    RoomlistComponent,
    ViewroomComponent,
    PaymentComponent,
    
    
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
