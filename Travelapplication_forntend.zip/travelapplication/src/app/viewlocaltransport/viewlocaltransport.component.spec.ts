import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewlocaltransportComponent } from './viewlocaltransport.component';

describe('ViewlocaltransportComponent', () => {
  let component: ViewlocaltransportComponent;
  let fixture: ComponentFixture<ViewlocaltransportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewlocaltransportComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewlocaltransportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
