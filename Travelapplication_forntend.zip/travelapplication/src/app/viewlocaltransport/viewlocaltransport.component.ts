import { Component, OnInit } from '@angular/core';
import { LocaltransportService } from '../service/localtransport.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-viewlocaltransport',
  standalone: false,
  
  templateUrl: './viewlocaltransport.component.html',
  styleUrl: './viewlocaltransport.component.css'
})
export class ViewlocaltransportComponent implements OnInit {
localtransportlist:any;

  ngOnInit(): void {
    this.localtransportservice.getAllLocalTransports().subscribe(
      (response) => {
        this.localtransportlist = response;
      }
    )
  }
  constructor(private router:Router,activaterouter:ActivatedRoute,private localtransportservice:LocaltransportService){

  }
  booklocaltransport(localtransportId:any){
    
  }
}
