import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from '../service/user.service';
import { Router } from '@angular/router';
import { OnInit } from '@angular/core';

@Component({
  selector: 'app-adminhome',
  standalone: false,
  
  templateUrl: './adminhome.component.html',
  styleUrl: './adminhome.component.css'
})
export class AdminhomeComponent implements OnInit{
 userId:any;
  user:any;
  userName:any;
  ngOnInit(): void {
    this.userId=this.activateRoute.snapshot.params['userId'];
    this.userService.getUserById(this.userId).subscribe(
      (response:any)=>
      {
        this.user=response;
        this.userName=this.user.username;
      }
    )
  }

   constructor (
      private  router: Router, private activateRoute: ActivatedRoute,private userService:UserService
    ){
      
    }
    hotel(){
      this.router.navigate(['hotel',this.userId]);//It navigates to app-routing.module.ts
      console.log("hotel ");
    }
    
    booking(){
      this.router.navigate(['booking']);//It navigates to app-routing.module.ts
      console.log("bookings");
    }
    transport(){
      this.router.navigate(['transport',this.userId]);//It navigates to app-routing.module.ts
      console.log("transport");
    }
    localtransport(){
      this.router.navigate(['localtransport',this.userId]);//It navigates to app-routing.module.ts
      console.log("localtransport");
    }
    room(){
      this.router.navigate(['room',this.userId]);//It navigates to app-routing.module.ts
      console.log("room");
    }
    viewhotels(){
   //   this.router.navigate(['hotellisturl',this.userId]);
   this.router.navigate(['hotellisturl']);
      
    }

    viewtransport(){
      this.router.navigate(['transportlisturl']);
      
    }
    viewlocaltransport(){
      this.router.navigate(['localtransportlisturl']);
      
    }
    viewroom(){
      this.router.navigate(['roomurl']);
    
}
}
