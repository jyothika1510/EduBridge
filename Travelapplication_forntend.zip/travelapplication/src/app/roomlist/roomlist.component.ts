import { Component, OnInit } from '@angular/core';
import { Room } from '../model/room';
import { ActivatedRoute } from '@angular/router';
import { HotelService } from '../service/hotel.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-roomlist',
  standalone: false,
  
  templateUrl: './roomlist.component.html',
  styleUrl: './roomlist.component.css'
})
export class RoomlistComponent implements OnInit {
  checkInDate:any;
  checkOutDate:any;
roomlist: any;
hotelId : any;
userId:any;

ngOnInit(): void {
  this.hotelId=this.activatedrouter.snapshot.params['hotelId'];
  this.userId=sessionStorage.getItem('userId');
  this.hotelservice.viewRoom(this.hotelId).subscribe(
    (response:any)=>
    {
      this.roomlist=response;
    }
  )

}
constructor(private router:Router,private activatedrouter:ActivatedRoute,private hotelservice:HotelService){

}
bookRoom(roomId:any)
{
  this.hotelservice.bookRoom(this.userId,roomId,this.hotelId);
 /* .subscribe(
    (Response:any)=>{
      if(Response!=null)
      alert("booking is done , please do the payment");
    
    }
  )*/
}
}
