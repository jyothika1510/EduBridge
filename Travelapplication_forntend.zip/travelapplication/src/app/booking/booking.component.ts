import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-booking',
  standalone: false,
  
  templateUrl: './booking.component.html',
  styleUrl: './booking.component.css'
})
export class BookingComponent implements OnInit{
booking:any
deletebooking: any;
  ngOnInit(): void {
    {
this.booking.getAllLocalTransports.subscribe(
  (Response:any)=>{
    this.LocalTransport=Response;
  }

)
    }
    
  }constructor(private router:Router,private activaterouter:ActivatedRoute){
    
  }






Hotels(hotelId:any) {

}
Transport(transportId:any) {

}
LocalTransport(localtransportId:any) {

}

}
