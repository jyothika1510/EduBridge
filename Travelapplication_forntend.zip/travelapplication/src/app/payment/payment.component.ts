import { Component, OnInit } from '@angular/core';
import { HotelService } from '../service/hotel.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Payment } from '../model/payment';
import { TransportService } from '../service/transport.service';
import { LocaltransportService } from '../service/localtransport.service';

@Component({
  selector: 'app-payment',
  standalone: false,
  
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.css'
})
export class PaymentComponent implements OnInit {
paymentId: any;

  userId:any;
  paymentList:any;
  payment=new Payment();
  ngOnInit(): void {
    this.userId=sessionStorage.getItem('userId');
    this.hotelservice.getAllPaymentsByUserId(this.userId).subscribe(
      (response:any)=>{
        this.paymentList=response;

        alert("payment is done");
      }

    )
  }

  constructor(private hotelservice:HotelService,private router:Router,private activaterouter:ActivatedRoute,private transportservice:TransportService,private localtransportservice:LocaltransportService){

  }
  submit(paymentid:any) {
  

    this.hotelservice.updatePaymentStatus(paymentid,this.payment).subscribe(
      (Response:any)=>
      {
        if(Response!=null)
        alert("payment is done ");
      else
      alert("payment failed check the details");
      }
    )
    }

}
