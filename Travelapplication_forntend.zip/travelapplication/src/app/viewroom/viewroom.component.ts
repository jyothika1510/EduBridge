import { Component, OnInit } from '@angular/core';
import { HotelService } from '../service/hotel.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Room } from '../model/room';
import { Payment } from '../model/payment';
@Component({
  selector: 'app-viewroom',
  standalone: false,
  
  templateUrl: './viewroom.component.html',
  styleUrl: './viewroom.component.css'
})
export class ViewroomComponent implements OnInit{
roomlist: any;
room:any;

  userId: any;
  hotellist: any;
checkInDate: any;
checkOutDate: any;
  hotelId: any;
  numberOfDays: any;
  payment=new Payment();
  
  ngOnInit(): void {
    this.userId=sessionStorage.getItem('userId');
    this.hotelId=this.activaterouter.snapshot.params['hotelId'];
    console.log(this.userId)
    console.log(this.hotelId)
      this.hotelservice.viewRoom(this.hotelId).subscribe(
        (response:any) => {
          this.roomlist=response;
        }
      )
  }


  constructor(private hotelservice:HotelService,private router:Router,private activaterouter:ActivatedRoute){

  }
  
  bookRoom(roomId: any,roomprice:any) {
    console.log("inside the bookroom");
    const startDate = new Date(this.checkInDate);
  const endDate = new Date(this.checkOutDate);
    const diffInMs = Math.abs(endDate.getTime() - startDate.getTime());

    // Calculate the difference in days
    this.numberOfDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));
console.log(this.numberOfDays);
console.log(roomId);
console.log(roomprice);
this.payment.price=this.numberOfDays*roomprice;
console.log(this.payment.price);

// this.hotelservice.getRoomById(roomId).subscribe(
//   (Response:any)=>{
//     console.log(Response);
// this.room=Response
//   }
//)

    this.hotelservice.addBookings(this.userId,roomId,this.hotelId,this.payment).subscribe(
           (Response:any)=>{
             if(Response!=null){
            alert("booking is done , please do the payment");
             this.hotelservice.updateRoomAvailableStatus(roomId,this.room).subscribe(
              (response:any)=>
                {
                  if(response!=null)
                  alert("roomstatus updated");
                }
           
             )
             this.router.navigate(['paymenturl']);
             }
           }
        )
    }
}
