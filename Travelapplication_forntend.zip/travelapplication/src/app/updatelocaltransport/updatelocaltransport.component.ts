import { Component, OnInit } from '@angular/core';
import { LocaltransportService } from '../service/localtransport.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-updatelocaltransport',
  standalone: false,
  
  templateUrl: './updatelocaltransport.component.html',
  styleUrl: './updatelocaltransport.component.css'
})
export class UpdatelocaltransportComponent implements OnInit {
localtransportId:any;
  localtransport:any;
ngOnInit(): void {
this.localtransportId=this.activateroute.snapshot.params['localtransportId'];
 this.localtransportservice.getLocalTransportById(this.localtransportId).subscribe(
  (Response:any)=>{
    console.log(Response);
    this.localtransport=Response;
    console.log(this.localtransport);
  }
 ) 
}
constructor(private activateroute:ActivatedRoute,private localtransportservice:LocaltransportService,private router:Router){

}
onSubmit(){
this.localtransportservice.updateLocalTransportById(this.localtransportId, this.localtransport).subscribe(
  ((Response:any)=>{
    alert("updated sucessfully");
    this.router.navigate(['localtransportlisturl'])
  })
)
}
Onback(){
  
}
}
