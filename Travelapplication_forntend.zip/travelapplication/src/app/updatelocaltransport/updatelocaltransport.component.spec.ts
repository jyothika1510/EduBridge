import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatelocaltransportComponent } from './updatelocaltransport.component';

describe('UpdatelocaltransportComponent', () => {
  let component: UpdatelocaltransportComponent;
  let fixture: ComponentFixture<UpdatelocaltransportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UpdatelocaltransportComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdatelocaltransportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
