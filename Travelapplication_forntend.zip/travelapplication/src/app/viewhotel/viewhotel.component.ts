import { Component, OnInit } from '@angular/core';
import { HotelService } from '../service/hotel.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Booking } from '../model/booking';
@Component({
  selector: 'app-viewhotel',
  standalone: false,
  
  templateUrl: './viewhotel.component.html',
  styleUrl: './viewhotel.component.css'
})
export class ViewhotelComponent implements OnInit{
  hotellist:any
  
  
  booking=new Booking();
userId:any;
room: any;
roomId: any;
checkInDate="";
  checkOutDate="";
  hotelId: any;
addBookings: any;
    ngOnInit(): void {
      this.userId=sessionStorage.getItem('userId');
      this.hotelservice.getalhotels().subscribe(
        (response) => {
          this.hotellist = response;
        }
      )
  }
  constructor(private hotelservice:HotelService,private router:Router,private activaterouter:ActivatedRoute){
    
  }
  viewroom(hotelId:any){
    this.router.navigate(['viewroom',hotelId]);
}
  }
  // bookRoom(roomId:any)
  // {
  //   this.hotelservice.addBookings(this.userId,roomId,this.hotelId).subscribe(
  //     (Response:any)=>{
  //       if(Response!=null)
  //       alert("booking is done , please do the payment");
      
  //     }
  //   )
  // }





