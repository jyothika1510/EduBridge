import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { LocaltransportService } from '../service/localtransport.service';



@Component({
  selector: 'app-localtransportlist',
  standalone: false,
  
  templateUrl: './localtransportlist.component.html',
  styleUrl: './localtransportlist.component.css'
})
export class LocaltransportlistComponent implements OnInit{
localtransportlist:any;

  ngOnInit(): void {
    this.localtransportservice.getAllLocalTransports().subscribe(
      (response) => {
        this.localtransportlist = response;
      }
    )
  }
  constructor(private router:Router,activaterouter:ActivatedRoute,private localtransportservice:LocaltransportService){

  }
  deletelocaltransport(localtransportId:any)
  {
    let flag = confirm("Are you sure you want to delete this");
    if(flag===true){
this.localtransportservice.deleteLocalTransportById(localtransportId).subscribe(
  (response:any)=>
  {
    this.localtransportlist=response;
    this.router.navigate(['localtransportlisturl']);
  }
)
    }
  }
  updatelocaltransport(localtransportId:any)
  {
    let flag = confirm("Are you sure you want to update this");
    if(flag===true){
      this.router.navigate(['updatelocaltransporturl',localtransportId]);
    }

  }
}
