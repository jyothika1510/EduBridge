import { Component } from '@angular/core';
import { User } from '../model/user';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-signup',
  standalone: false,
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'], // Corrected to "styleUrls"
})
export class SignupComponent {
  // Initialize a new User object
  user = new User();

  constructor(private userService: UserService) {}

  // Handle form submission
  onSubmit() {
    console.log("control");
    console.log(this.user);

    this.userService.userSignUp(this.user).subscribe(
      (response) => {
        console.log("Response from backend:", response);
        alert("User signup successful!");
      },
      (error) => {
        console.error("Error during signup:", error);
        alert("An error occurred during signup. Please try again.");
      }
    );
  }
}
