import { Component, OnInit } from '@angular/core';
import { TransportService } from '../service/transport.service';
import { Route } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
@Component({
  selector: 'app-transportlist',
  standalone: false,
  
  templateUrl: './transportlist.component.html',
  styleUrl: './transportlist.component.css'
})
export class TransportlistComponent implements OnInit {

transportlist:any

  ngOnInit(): void {
    this.transportservice.getAllTransports().subscribe(
      (response) => {
        this.transportlist = response;
      }
    )
  }
  constructor(private router:Router,activaterouter:ActivatedRoute,private transportservice:TransportService){

  }
  deleteTransport(transportId:any)
  {
    let flag = confirm("Are you sure you want to delete this");
    if(flag===true){
this.transportservice.deleteTransportById(transportId).subscribe(
  (response:any)=>
  {
    this.transportlist=response;
    this.router.navigate(['transportlisturl']);
  }
)
    }
  }
  updateTransport(transportId:any)
  {
    let flag = confirm("Are you sure you want to update this");
    if(flag===true){
      this.router.navigate(['updatetransporturl',transportId]);
    }

  }
}
