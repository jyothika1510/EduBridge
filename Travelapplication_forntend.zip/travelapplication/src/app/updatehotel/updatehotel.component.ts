import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HotelService } from '../service/hotel.service';

@Component({
  selector: 'app-updatehotel',
  standalone: false,
  
  templateUrl: './updatehotel.component.html',
  styleUrl: './updatehotel.component.css'
})
export class UpdatehotelComponent implements OnInit{
  hotelId:any;
  hotel:any;
ngOnInit(): void {
this.hotelId=this.activateroute.snapshot.params['hotelId'];
 this.hotelservice.gethotelbyId(this.hotelId).subscribe(
  (Response:any)=>{
    console.log(Response);
    this.hotel=Response;
    console.log(this.hotel);
  }
 ) 
}
constructor(private activateroute:ActivatedRoute,private hotelservice:HotelService,private router:Router){

}
onSubmit(){
this.hotelservice.updateHotelById(this.hotelId, this.hotel).subscribe(
  ((Response:any)=>{
    alert("updated sucessfully");
    this.router.navigate(['hotellisturl'])
  })
)
}
Onback(){
  
}
}
