import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HotelService } from '../service/hotel.service';

@Component({
  selector: 'app-hotellist',
  standalone: false,
  
  templateUrl: './hotellist.component.html',
  styleUrl: './hotellist.component.css'
})
export class HotellistComponent  implements OnInit{
  hotellist:any;
  userId:any;


  ngOnInit(): void {
    this.userId=this.activaterouter.snapshot.params['userId'];
    this.hotelservice.getalhotels().subscribe(
      (response) => {
        this.hotellist = response;
      }
    )
  }
  constructor(private router:Router,private activaterouter:ActivatedRoute,private hotelservice:HotelService){

  }
  deleteHotel(hotelId:any)
  {
    let flag = confirm("Are you sure you want to delete this");
    if(flag===true){
this.hotelservice.deleteHotelByHotelId(hotelId).subscribe(
  (response:any)=>
  {
    this.hotellist=response;
    this.router.navigate(['hotellisturl']);
  }
)
    }
  }
  updateHotel(hotelId:any)
  {
    let flag = confirm("Are you sure you want to update this");
    if(flag===true){
      this.router.navigate(['updatehotelurl',hotelId]);
    }

  }
  addRoom(hotelId:any)
  {
    this.router.navigate(['addroomurl',hotelId]);
  }
  roomlist(hotelId:any){
    this.router.navigate(['roomlisturl',hotelId]);

  }

}
