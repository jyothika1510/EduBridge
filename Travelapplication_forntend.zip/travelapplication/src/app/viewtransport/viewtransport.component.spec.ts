import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewtransportComponent } from './viewtransport.component';

describe('ViewtransportComponent', () => {
  let component: ViewtransportComponent;
  let fixture: ComponentFixture<ViewtransportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewtransportComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewtransportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
