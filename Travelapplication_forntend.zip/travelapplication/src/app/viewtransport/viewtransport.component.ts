import { Component, OnInit } from '@angular/core';
import { TransportService } from '../service/transport.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-viewtransport',
  standalone: false,
  
  templateUrl: './viewtransport.component.html',
  styleUrl: './viewtransport.component.css'
})
export class ViewtransportComponent implements OnInit {
  transportlist:any
  ngOnInit(): void {
    this.transportservice.getAllTransports().subscribe(
      (response) => {
        this.transportlist = response;
      }
    )
  }
  constructor(private transportservice:TransportService,private router:Router,private activaterouter:ActivatedRoute ){

  }
  booktransport(transportId:any){
    

  }

}
