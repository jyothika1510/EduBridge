import { Component, OnInit } from '@angular/core';
import { Room } from '../model/room';
import { ActivatedRoute, Router } from '@angular/router';
import { HotelService } from '../service/hotel.service';
@Component({
  selector: 'app-addroom',
  standalone: false,
  
  templateUrl: './addroom.component.html',
  styleUrl: './addroom.component.css'
})
export class AddroomComponent implements OnInit{
  room = new Room();
  hotelId:any;

  ngOnInit(): void {
    this.hotelId=this.activaterouter.snapshot.params['hotelId'];
    
  }
  constructor(private router:Router,private activaterouter:ActivatedRoute,private hotelservice:HotelService){

  }
onSubmit(){
  this.hotelservice.addRoom(this.room,this.hotelId).subscribe(
    (response:any)=>
    {
      alert("room added sucessfull");
      this.router.navigate(['hotellisturl']);
    }

  )
}
}
