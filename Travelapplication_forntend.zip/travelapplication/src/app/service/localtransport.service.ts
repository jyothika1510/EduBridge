import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class LocaltransportService {
  url = "http://localhost:8089/api/localtransport";

  constructor(private httpClient: HttpClient) {}

  
  addLocalTransport(localTransport: any) {
    return this.httpClient.post(`${this.url}/addtransport`, localTransport);
  }

  // Get all local transports
  getAllLocalTransports() {
    return this.httpClient.get(`${this.url}/getalllocaltransport`);
  }

  // Delete a local transport by ID
  deleteLocalTransportById(localTransportId: any) {
    return this.httpClient.delete(`${this.url}/deletebyid/${localTransportId}`);
  }

  // Get a local transport by ID
  getLocalTransportById(localTransportId: any) {
    return this.httpClient.get(`${this.url}/getlocaltransportbyid/${localTransportId}`);
  }

  // Update a local transport by ID
  updateLocalTransportById(localTransportId: any, localTransport: any) {
    return this.httpClient.put(`${this.url}/updatetransport/${localTransportId}`, localTransport);
  }
}