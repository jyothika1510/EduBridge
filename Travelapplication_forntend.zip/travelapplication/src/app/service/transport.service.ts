import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TransportService {
  url = "http://localhost:8089/api/transport";

  constructor(private httpClient: HttpClient) {}

  addTransport(transport: any) {
    return this.httpClient.post(`${this.url}/addtransport`, transport);
  }

  getAllTransports() {
    return this.httpClient.get(`${this.url}/getalltransport`);
  }

  deleteTransportById(transportId: any) {
    return this.httpClient.delete(`${this.url}/deletebyid/${transportId}`);
  }

  getTransportById(transportId: any) {
    return this.httpClient.get(`${this.url}/gettransportbyid/${transportId}`);
  }

  updateTransportById(transportId: any, transport: any) {
    return this.httpClient.put(`${this.url}/updatetransport/${transportId}`, transport);
  }
}
