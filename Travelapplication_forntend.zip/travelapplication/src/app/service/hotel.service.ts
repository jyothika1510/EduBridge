import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HotelService {
url = "http://localhost:8089/api/hotel";
url1="http://localhost:8089/api";
url2="http://localhost:8089/api/room";
url3="http://localhost:8089/api/payments";
  getRoomPrice: any;
  constructor(private httpClient:HttpClient) {}

  addhotel(hotel:any){
    return this.httpClient.post(`${this.url}/addhotel`,hotel);
  }
getalhotels(){
  return this.httpClient.get(`${this.url}/gethotels`);
}
deleteHotelByHotelId(hotelId:any)
{
  return this.httpClient.delete(`${this.url}/deletehotelbyid/${hotelId}`);
}
gethotelbyId(hotelId:any){
  return this.httpClient.get(`${this.url}/gethotelbyid/${hotelId}`);
}

updateHotelById(hotelId:any,hotel:any)
{
  return this.httpClient.put(`${this.url}/updatehotel/${hotelId}`,hotel);
}
addBookings(userId:any,roomId:any,hotelId:any,payment:any)
{
return this.httpClient.post(`${this.url3}/${userId}/${roomId}/${hotelId}`,payment);
}
addRoom(room:any,hotelId:any){
  return this.httpClient.post(`${this.url2}/addroom/${hotelId}`,room);
}
viewRoom(hotelId:any){
  return this.httpClient.get(`${this.url2}/getRoombyHotelid/${hotelId}`);
}
bookRoom(userId:any,roomId:any,hotelId:any)
{
return null;
}
getRoomById(roomId:any){
  return this.httpClient.get(`${this.url2}/getRoombyid/${roomId}`);
}
getAllPaymentsByUserId(userId:any){
  return this.httpClient.get(`${this.url3}/getpaymentbyuserid/${userId}`);
}
updatePaymentStatus(paymentid:any,payment:any)
{
return this.httpClient.put(`${this.url3}/updatepaymentstatus/${paymentid}`,payment);
}
updateRoomAvailableStatus(roomId:any,room:any)
{
  return this.httpClient.put(`${this.url2}/updateroomstatus/${roomId}`,room);
}
}
