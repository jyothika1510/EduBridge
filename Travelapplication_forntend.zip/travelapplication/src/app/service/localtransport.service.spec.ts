import { TestBed } from '@angular/core/testing';

import { LocaltransportService } from './localtransport.service';

describe('LocaltransportService', () => {
  let service: LocaltransportService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LocaltransportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
