package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.LocalTransport;
import com.example.entity.Transport;
import com.example.service.LocalTransportService;

@RestController
@CrossOrigin(origins="http://localhost:4200/") 
@RequestMapping("/api/localtransport")
public class LocalTransportControl {
@Autowired
private LocalTransportService localtransportService;
@PostMapping("/addtransport")
public  ResponseEntity<LocalTransport> addLocalTransport(@RequestBody LocalTransport localTransport) {
	// TODO Auto-generated method stub
	return new ResponseEntity<LocalTransport>(localtransportService.addLocalTransport(localTransport),HttpStatus.CREATED);
	
}

@GetMapping("/getalllocaltransport")
public ResponseEntity<List<LocalTransport>> getAllLocalTransport() {
	// TODO Auto-generated method stub
	return new ResponseEntity<List<LocalTransport>>(localtransportService.getAllLocalTransport(),HttpStatus.OK);
}
@GetMapping("/getlocaltransportbyid/{localtransport_id}")
public ResponseEntity<LocalTransport> getLocalTransportById(@PathVariable Long localtransport_id) {
	// TODO Auto-generated method stub
	return new ResponseEntity<LocalTransport>(localtransportService.getLocalTransportById(localtransport_id),HttpStatus.OK);
}
@DeleteMapping("/deletebyid/{localtransport_id}")
public ResponseEntity<List<LocalTransport>> deleteLocalTransport( @PathVariable Long localtransport_id) {
	// TODO Auto-generated method stub
	
	return new ResponseEntity<List<LocalTransport>>(localtransportService.deleteLocalTransport(localtransport_id),HttpStatus.OK);
}

@PutMapping("/updatetransport/{transport_id}")
public ResponseEntity<LocalTransport> updateLocalTransport(@PathVariable Long localtransport_id, @RequestBody LocalTransport localtransport) {
	// TODO Auto-generated method stub
	return new ResponseEntity<LocalTransport>(localtransportService.updateLocalTransport(localtransport_id, localtransport),HttpStatus.OK);

}
}
