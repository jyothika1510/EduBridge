
package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Hotel;
import com.example.service.HotelService;


@RestController
@CrossOrigin(origins="http://localhost:4200/")
@RequestMapping("api/hotel")//this works only when this url is given  

public class HotelControl {   
	
@Autowired
private HotelService hotelService;
@PostMapping("/addhotel")
public ResponseEntity<Hotel> addHotel( @RequestBody Hotel hotel) {
	// TODO Auto-generated method stub
	return  new ResponseEntity<Hotel>(hotelService.addHotel(hotel),HttpStatus.CREATED) ;
}

@GetMapping("/gethotels")
public ResponseEntity<List<Hotel>> getAllHotels() {
	// TODO Auto-generated method stub
	return new ResponseEntity<List<Hotel>>(hotelService.getAllHotels(),HttpStatus.OK);
}


@GetMapping("/gethotelbyid/{hotel_id}")
public ResponseEntity<Hotel> getHotelById(@PathVariable("hotel_id") Long hotel_id) {
	// TODO Auto-generated method stub
	return new ResponseEntity<Hotel>(hotelService.getHotelById(hotel_id),HttpStatus.OK);
}
@PutMapping("/updatehotel/{hotelId}")
	public ResponseEntity <Hotel> updateHotel( @PathVariable("hotelId") Long hotel_id, @RequestBody Hotel hotel) {
	
	return new ResponseEntity<Hotel>(hotelService.updateHotel(hotel_id, hotel),HttpStatus.CREATED);
}
@DeleteMapping("/deletehotelbyid/{hotelId}")
public List<Hotel> deleteHotel(@PathVariable("hotelId") Long hotel_id){
	
		return	hotelService.deleteHotel(hotel_id);
		//	return new ResponseEntity<String>("hotel is deleted",HttpStatus.OK);
}
@GetMapping("/hotelLocation/{hotel_location}")
public ResponseEntity<Hotel> findByHotelLocation(@PathVariable("hotel_location")String hotel_location)  
{
	return new ResponseEntity<Hotel>(hotelService.findByHotelLocation(hotel_location),HttpStatus.OK);
}

@GetMapping("/PetFriendly/{petFriendly}")
public ResponseEntity<Hotel> findByPetFriendly(@PathVariable("petFriendly")boolean petFriendly)  
{
	return new ResponseEntity<Hotel>(hotelService.findByPetFriendly(petFriendly),HttpStatus.OK);
}
}

