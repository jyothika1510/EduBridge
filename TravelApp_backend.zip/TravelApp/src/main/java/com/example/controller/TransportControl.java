package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.LocalTransport;
import com.example.entity.Transport;
import com.example.service.TransportService;

@RestController
@CrossOrigin(origins="http://localhost:4200/")
@RequestMapping("api/transport")
public class TransportControl {
@Autowired
private TransportService transportService;
@PostMapping("/addtransport")
public  ResponseEntity<Transport> addtransport(@RequestBody Transport transport) {
	// TODO Auto-generated method stub
	return new ResponseEntity<Transport>(transportService.addtransport(transport),HttpStatus.CREATED);
}

@GetMapping("/getalltransport")
public ResponseEntity<List<Transport>> getAllTransport() {
	// TODO Auto-generated method stub
	return new ResponseEntity<List<Transport>>(transportService.getAllTransport(),HttpStatus.OK);
}


@GetMapping("/gettransportbyid/{transport_id}")
public ResponseEntity<Transport> getTransportById(@PathVariable Long transport_id) {
	// TODO Auto-generated method stub
	return new ResponseEntity<Transport>(transportService.getTransportById(transport_id),HttpStatus.OK);
}

@PutMapping("/updatetransport/{transport_id}")
public ResponseEntity<Transport> updateTransport(@PathVariable Long transport_id, @RequestBody Transport transport) {
	// TODO Auto-generated method stub
	return new ResponseEntity<Transport>(transportService.updateTransport(transport_id, transport),HttpStatus.OK);
}

@DeleteMapping("/deletebyid/{transport_id}")
public ResponseEntity<List<Transport>> deleteTransport( @PathVariable Long transport_id) {
	// TODO Auto-generated method stub
	
	return new ResponseEntity<List<Transport>>(transportService.deleteTransport(transport_id),HttpStatus.OK);
}

@GetMapping("/getbysource/{source}")
public ResponseEntity<List<Transport>> findBySource(@PathVariable String source) {
	// TODO Auto-generated method stub
	return new ResponseEntity<List<Transport>>(transportService.findBySource(source),HttpStatus.OK);
}
}
