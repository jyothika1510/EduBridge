package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Booking;
import com.example.entity.Hotel;
import com.example.service.BookingService;

@RestController
@RequestMapping("/api")
public class BookingControl {
 @Autowired
	    private BookingService bookingService;

	   
	    @PostMapping("/bookings/{userId}/{hotelId}/{roomId}")
	    public ResponseEntity<Booking> addBooking(@PathVariable("userId") int userId,@PathVariable("hotelId") long hotelId,@PathVariable("roomId") long roomId, @RequestBody Booking booking) {
	        Booking createdBooking = bookingService.addHotelBooking(booking,userId,hotelId,roomId);
	        return ResponseEntity.ok(createdBooking);
	    }
	    

	    @GetMapping("/getallbookings")
	    public ResponseEntity<List<Booking>> getAllBookings() {
	        List<Booking> bookings = bookingService.getAllBookings();
	        return ResponseEntity.ok(bookings);
	    }

	    // Endpoint to get a booking by ID
	    @GetMapping("/bookings/{booking_id}")
	    public ResponseEntity<Booking> getBookingById(@PathVariable Long booking_id) {
	        return new ResponseEntity<Booking>(bookingService.getBookingById(booking_id),HttpStatus.OK);
	        
	    }
	             
	    

	 
	    @DeleteMapping("/bookings/{id}")
	    public ResponseEntity<Void> deleteBooking(@PathVariable Long booking_id) {
	        bookingService.deleteBooking(booking_id);
	        return ResponseEntity.noContent().build();
	    }

}
