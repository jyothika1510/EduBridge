package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.entity.Payment;
import com.example.service.PaymentService;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins="http://localhost:4200/") 
public class PaymentController {

    @Autowired
    private PaymentService paymentService;


    @GetMapping("/{paymentId}")
    public ResponseEntity<Payment> getPaymentById(@PathVariable Long paymentId) {
       
         return new ResponseEntity<Payment>(paymentService.getPaymentById(paymentId),HttpStatus.OK);
    }

    @GetMapping("/getpaymentbyuserid/{userId}")
    public List<Payment> getAllPaymentByuserId(@PathVariable("userId") int userId) {
       
         return paymentService.getAllPaymentByuserId(userId);
    }

    @GetMapping
    public ResponseEntity<List<Payment>> getAllPayments() {

return new ResponseEntity<List<Payment>>(paymentService.getAllPayments(),HttpStatus.OK);
    }


    @PostMapping("/{userId}/{roomId}/{hotelId}")
    public ResponseEntity<Payment> addPayment(
            @PathVariable("userId") int userId,
            @PathVariable("roomId") long roomId,
            @PathVariable("hotelId") long hotelId,
            @RequestBody Payment payment) {

        Payment newPayment = paymentService.addPayment(userId, roomId, hotelId, payment);
        return new ResponseEntity<Payment>(newPayment,HttpStatus.CREATED); 
    } 
@PutMapping("/updatepaymentstatus/{paymentid}")
public ResponseEntity<Payment> updatepaymentstatus(@PathVariable("paymentid") Long paymentId, @RequestBody Payment payment)
{
	return new ResponseEntity<Payment>(paymentService.updatePaymentStatus(paymentId,payment),HttpStatus.OK);
}
    
    @DeleteMapping("/{paymentId}")
    public List<Payment> deletePayment(@PathVariable Long paymentId) {

          return paymentService.deletePayment(paymentId);
        	
	
    }
}