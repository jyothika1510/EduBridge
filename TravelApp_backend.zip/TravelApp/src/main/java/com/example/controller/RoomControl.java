package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Room;
import com.example.service.RoomService;

@RestController
@RequestMapping("api/room")
@CrossOrigin(origins="http://localhost:4200/") 
public class RoomControl {
	
	
	@Autowired
	private RoomService roomService;
	@PostMapping("/addroom/{hotelId}")
	public ResponseEntity<Room> addRoom(@PathVariable("hotelId") long hotelId, @RequestBody Room room) {
		// TODO Auto-generated method stub
		return  new ResponseEntity<Room>(roomService.addRoom(room,hotelId),HttpStatus.CREATED) ;
	}

	@GetMapping("/getrooms")
	public ResponseEntity<List<Room>> getAllRooms() {
		// TODO Auto-generated method stub
		return new ResponseEntity<List<Room>>(roomService.getAllRooms(),HttpStatus.OK);
	}


	@GetMapping("/getRoombyid/{room_id}")
	public ResponseEntity<Room> getRoomById(@PathVariable Long room_id) {
		// TODO Auto-generated method stub
		return new ResponseEntity<Room>(roomService.getRoomById(room_id),HttpStatus.OK);
	}
	@GetMapping("/getRoombyHotelid/{hotelId}")
	public List<Room> getRoomByHotelId(@PathVariable("hotelId") long hotelId) {
		// TODO Auto-generated method stub
		return roomService.getRoomsByHotelId(hotelId);
	}
	@PutMapping("/updateRoom/{room_id}")
		public ResponseEntity <Room> updateRoom( @PathVariable Long room_id, @RequestBody Room room) {
		
		return new ResponseEntity<Room>(roomService.updateRoom(room_id, room),HttpStatus.CREATED);
	}
	
	@PutMapping("/updateroomstatus/{room_id}")
	public ResponseEntity <Room> updateRoomStatus( @PathVariable("room_id") Long room_id, @RequestBody Room room) {
	
	return new ResponseEntity<Room>(roomService.updateRoomStatus(room_id, room),HttpStatus.CREATED);
}
	@DeleteMapping("/deleteRoomByid/{room_id}")
	public List<Room> deleteRoomById(@PathVariable Long room_id){
		
			return	roomService.deleteRoomById(room_id);
			//	return new ResponseEntity<String>("hotel is deleted",HttpStatus.OK);

	}
	}

