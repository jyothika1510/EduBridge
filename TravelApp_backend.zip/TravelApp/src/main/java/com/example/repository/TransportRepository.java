package com.example.repository;
import org.springframework.stereotype.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.entity.Transport;
public interface TransportRepository extends JpaRepository<Transport,Long> {
	@Query
	public List<Transport> findBySource(String source);
}











































































