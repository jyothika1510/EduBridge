package com.example.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entity.LocalTransport;
public interface LocalTransportRepository extends JpaRepository<LocalTransport,Long> {

}
