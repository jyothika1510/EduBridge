package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.example.entity.Users;

public interface UsersRepository extends JpaRepository<Users,Integer> {

	public  Users findByUsernameAndUserPassword(String username,String userPassword);
	
	public Users findByUsername(String username);
	
	public Users findByCity(String city);
	
	public Users findByPhone(String phone);
	
	public Users findByEmailId(String email);
}
