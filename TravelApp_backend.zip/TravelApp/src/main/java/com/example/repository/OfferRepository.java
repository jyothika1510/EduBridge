package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entity.Offer;

public interface OfferRepository extends JpaRepository<Offer,Long> {

}
