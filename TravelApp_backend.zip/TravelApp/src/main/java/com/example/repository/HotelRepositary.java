package com.example.repository;

import org.springframework.stereotype.Repository;

import com.example.entity.Hotel;

import org.hibernate.mapping.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


@Repository
public interface HotelRepositary extends JpaRepository<Hotel,Long> {

	public Hotel findByHotelLocation(String hotel_location);
	
	public Hotel findByPetFriendly(Boolean petFriendly);
}	

