package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.entity.Transport;

public interface TransportService {
	public Transport addtransport(Transport transport);
	public List<Transport> getAllTransport();
	public Transport getTransportById(Long transport_id); 
	public Transport updateTransport(Long transport_id, Transport updatedTransport);
	public List<Transport> deleteTransport(Long transport_id);
	public List<Transport> findBySource(String source);	
}
