package com.example.service;

import java.util.List;

import com.example.entity.Users;

public interface UsersService {
	public Users addUser(Users user) ;
	public Users loginUser(Users user) ;
	public Users findByUsername(String username);
	public Users findByCity(String city);
	public Users findByPhone(String phone) ;
	public Users findByEmailId(String email);
	public List<Users> getAllUsers() ;
	public List<Users> deleteUser(Integer userId);
	public Users updateAllUsers(Integer userId,Users user) ;
	public Users getUserById(Integer userId);
}
