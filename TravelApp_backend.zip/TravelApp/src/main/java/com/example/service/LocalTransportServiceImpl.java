
package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.LocalTransport;
import com.example.error.ResourceNotFoundException;
import com.example.repository.LocalTransportRepository;


@Service
public class LocalTransportServiceImpl implements LocalTransportService {
@Autowired
private LocalTransportRepository localtransportRepository;
	@Override
	public LocalTransport addLocalTransport(LocalTransport localTransport) {
		// TODO Auto-generated method stub
		return localtransportRepository.save(localTransport);
	}

	@Override
	public List<LocalTransport> getAllLocalTransport() {
		// TODO Auto-generated method stub
		return localtransportRepository.findAll();
	}

	@Override
	public LocalTransport getLocalTransportById(Long localtransport_id) {
		// TODO Auto-generated method stub
		return localtransportRepository.findById(localtransport_id).orElseThrow(()-> new ResourceNotFoundException("LocalTransport","localtransport_id","localtransport_id"));
	}

	@Override
	public LocalTransport updateLocalTransport(Long localtransport_id, LocalTransport updateLocalTransport) {
		// TODO Auto-generated method stub
		LocalTransport localTransport1 = getLocalTransportById(localtransport_id);
		localTransport1.setLocaltransport_type(updateLocalTransport.getLocaltransport_type());
		localTransport1.setPrice_per_km(updateLocalTransport.getPrice_per_km());
		localTransport1.setLocation(updateLocalTransport.getLocation());
		
		return localtransportRepository.save(localTransport1);
	}

	@Override
	public List<LocalTransport> deleteLocalTransport(Long localtransport_id) {
		// TODO Auto-generated method stub
		LocalTransport localtransport=getLocalTransportById(localtransport_id);
		localtransportRepository.deleteById(localtransport_id);
		return localtransportRepository.findAll();
	}

	
}
