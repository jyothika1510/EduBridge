package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Offer;
import com.example.error.ResourceNotFoundException;
import com.example.repository.OfferRepository;

@Service
public class OfferServiceImpl implements OfferService {
@Autowired
private OfferRepository offerRepository;
	@Override
	public Offer addOffer(Offer offer) {
		// TODO Auto-generated method stub
		return offerRepository.save(offer);
	}

	@Override
	public List<Offer> getAllOffers() {
		// TODO Auto-generated method stub
		return offerRepository.findAll();
	}

	@Override
	public Offer getOfferById(Long offer_id) {
		// TODO Auto-generated method stub
		return offerRepository.findById(offer_id).orElseThrow(()-> new ResourceNotFoundException("Offer","offer_id","offer_id"));
	}

	@Override
	public List<Offer> deleteOffer(Long offer_id) {
		// TODO Auto-generated method stub
		offerRepository.deleteById(offer_id);
		 return offerRepository.findAll();
	}

}
