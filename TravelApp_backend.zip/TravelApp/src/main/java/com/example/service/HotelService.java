package com.example.service;

import java.util.List;



import com.example.entity.Hotel;

public interface HotelService {
public Hotel addHotel(Hotel hotel);
public List<Hotel> getAllHotels();
public Hotel getHotelById(Long id); 
public Hotel updateHotel(Long id, Hotel hotel);
public List<Hotel> deleteHotel(Long id);
public Hotel findByHotelLocation(String hotel_location);
public Hotel findByPetFriendly(boolean petFriendly);	
}
