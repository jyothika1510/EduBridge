package com.example.service;


import java.util.List;

import com.example.entity.Payment;

public interface PaymentService {


   public  Payment getPaymentById(Long paymentId);

  public   List<Payment> getAllPayments();

 //public Payment addPayment(int userId, long hotelId, Long transport_id, Long localtransport_id, Long room_id, Payment payment);
  public Payment addPayment(int userId, long roomId, long hotelId, Payment payment);

  public  List<Payment> deletePayment(Long paymentId);

public List<Payment> getAllPaymentByuserId(int userId);

public Payment updatePaymentStatus(Long paymentId,Payment payment);
}