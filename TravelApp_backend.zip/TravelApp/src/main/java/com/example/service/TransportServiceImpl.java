package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Transport;
import com.example.error.ResourceNotFoundException;
import com.example.repository.TransportRepository;


@Service
public class TransportServiceImpl implements TransportService{
	@Autowired
	private TransportRepository transportRepository;
	@Override
	public Transport addtransport(Transport transport) { //id=1,type=bus,
		// TODO Auto-generated method stub
		return transportRepository.save(transport);
		//save methods returns the serialized id with student object
	}

	@Override
	public List<Transport> getAllTransport() {
		// TODO Auto-generated method stub
		return transportRepository.findAll();
	}

	@Override
	public Transport getTransportById(Long transport_id) {
		// TODO Auto-generated method stub
		return transportRepository.findById(transport_id).orElseThrow(()-> new ResourceNotFoundException("Transport","transport_id","transport_id"));
	}

	@Override
	public Transport updateTransport(Long transport_id, Transport transport) {
		// TODO Auto-generated method stub
		Transport transport1=getTransportById(transport_id);
		transport1.setDestination(transport.getDestination());
		transport1.setSource(transport.getSource());
		transport1.setTransport_type(transport.getTransport_type());
		transport1.setPrice(transport.getPrice());
		transport1.setDate(transport.getDate());
		transport1.setTime(transport.getTime());
		return transportRepository.save(transport1);
	}

	@Override
	public List<Transport> deleteTransport(Long transport_id) {
		// TODO Auto-generated method stub
		Transport transport=getTransportById(transport_id);
		transportRepository.deleteById(transport_id);
		return transportRepository.findAll();
		
	}

	@Override
	public List<Transport> findBySource(String source) {
		// TODO Auto-generated method stub
		return transportRepository.findBySource(source);
	}

}
