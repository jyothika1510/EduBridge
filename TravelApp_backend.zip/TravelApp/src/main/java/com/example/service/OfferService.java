package com.example.service;

import java.util.List;

import com.example.entity.Offer;

public interface OfferService {
public	Offer addOffer(Offer offer);

 public List<Offer> getAllOffers();

  public Offer getOfferById(Long offerId);

 public  List<Offer> deleteOffer(Long offerId);
}
