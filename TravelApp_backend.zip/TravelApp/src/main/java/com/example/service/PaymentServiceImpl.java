package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.stereotype.Service;

import com.example.entity.Hotel;
import com.example.entity.LocalTransport;
import com.example.entity.Payment;
import com.example.entity.Room;
import com.example.entity.Transport;
import com.example.entity.Users;
import com.example.error.ResourceNotFoundException;
import com.example.repository.PaymentRepository;


@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;
 @Autowired
	    private UsersService userService;
 @Autowired
	    private HotelService hotelService;
@Autowired
	    private RoomService roomService;
 @Autowired
	    private TransportService transportService;
@Autowired
	    private LocalTransportService localTransportService;


  

    @Override
    public Payment getPaymentById(Long paymentId) {
     return paymentRepository.findById(paymentId).orElseThrow(() -> new ResourceNotFoundException("Payment", "paymentId", "paymentId"));
    }
        

    @Override
    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    public Payment addPayment(int userId, long roomId, long hotelId, Payment payment) {
       
	        
    	 Users user = userService.getUserById(userId);
	        payment.setUser(user);
 
	      
	        Hotel hotel = hotelService.getHotelById(hotelId);
	        payment.setHotel(hotel);

	        Room room = roomService.getRoomById(roomId);
	        payment.setRoom(room);
	    
	        
	        
	        return paymentRepository.save(payment);


    }

    @Override
    public List<Payment> deletePayment(Long paymentId) {
        paymentRepository.deleteById(paymentId);

	        return paymentRepository.findAll(); 
    }


	@Override
	public List<Payment> getAllPaymentByuserId(int userId) {
		// TODO Auto-generated method stub
		return paymentRepository.findByUserUserId(userId);
	}


	@Override
	public Payment updatePaymentStatus(Long paymentId,Payment payment1) {
		// TODO Auto-generated method stub
		Payment payment = getPaymentById(paymentId);
		
		payment.setPaymentStatus("Payment Done");
		return paymentRepository.save(payment);
	}


	
		
	}
	
