package com.example.service;

import java.util.List;

import com.example.entity.LocalTransport;
import com.example.entity.Transport;

public interface LocalTransportService {
public LocalTransport addLocalTransport(LocalTransport localTransport);
public List<LocalTransport> getAllLocalTransport();
public LocalTransport getLocalTransportById(Long localtransport_id); 
public LocalTransport updateLocalTransport(Long localtransport_id, LocalTransport updateLocalTransport);
public List<LocalTransport> deleteLocalTransport(Long localtransport_id);
}
