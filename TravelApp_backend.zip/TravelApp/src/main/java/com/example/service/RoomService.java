package com.example.service;

import java.util.List;

import com.example.entity.Room;

public interface RoomService {

	public Room addRoom(Room room, long hotelId);
	    	public List<Room> getAllRooms();
	    	public Room getRoomById(Long room_id);
	    	public List<Room> getRoomsByHotelId(long hotel_id);
	    	public Room updateRoom(Long room_id, Room room);
	    	public List<Room> deleteRoomById(Long room_id);
			public Room updateRoomStatus(Long room_id, Room room);

}
