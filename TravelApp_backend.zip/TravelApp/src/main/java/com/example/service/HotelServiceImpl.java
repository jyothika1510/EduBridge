package com.example.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Hotel;


import com.example.service.HotelService;
import com.example.error.*;
import com.example.repository.HotelRepositary;

@Service
public class HotelServiceImpl implements HotelService {
@Autowired
private HotelRepositary  hotelRepository;

	@Override
	public Hotel addHotel(Hotel hotel) {
		// TODO Auto-generated method stub
		return hotelRepository.save(hotel) ;
	}

	@Override
	public List<Hotel> getAllHotels() {
		// TODO Auto-generated method stub
		return hotelRepository.findAll();
	}

	@Override
	public Hotel getHotelById(Long hotel_id) {
		// TODO Auto-generated method stub
		return hotelRepository.findById(hotel_id).orElseThrow(()-> new ResourceNotFoundException("Hotel","hotel_id","hotel_id"));
	}

	@Override
	public Hotel updateHotel(Long hotel_id, Hotel hotel) {
		
		// TODO Auto-generated method stub
		Hotel hotel1 = getHotelById(hotel_id);
		hotel1.setHotel_name(hotel.getHotel_name());
		hotel1.setHotelLocation(hotel.getHotelLocation());
		hotel1.setHotel_price_per_night(hotel.getHotel_price_per_night());
		hotel1.setHotel_rating(hotel.getHotel_rating());
		hotel1.setHotel_review(hotel.getHotel_review());
		return hotelRepository.save(hotel1) ;
	}

	@Override
	public List<Hotel> deleteHotel(Long hotel_id) {
		// TODO Auto-generated method stub
		 hotelRepository.deleteById(hotel_id);
		 return hotelRepository.findAll();
	}

	
 
	

	@Override
	public Hotel findByHotelLocation(String hotel_location) {
		// TODO Auto-generated method stub
		return hotelRepository.findByHotelLocation(hotel_location);
	}

	@Override
	public Hotel findByPetFriendly(boolean petFriendly) {
		// TODO Auto-generated method stub
		return hotelRepository.findByPetFriendly(petFriendly);
	}
	

}
