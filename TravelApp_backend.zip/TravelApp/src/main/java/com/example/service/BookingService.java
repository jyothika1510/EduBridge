package com.example.service;

import java.util.List;

import com.example.entity.Booking;

public interface BookingService {
	public Booking addBooking(Booking booking, int userId, long hotel_id,Long transport_id,Long localtransport_id);
	
	public Booking addHotelBooking(Booking booking, int userId,long hotelId,long roomId);

	 public List<Booking> getAllBookings();

	   public Booking getBookingById(Long booking_id);

	   public List<Booking>deleteBooking(Long booking_id);
}