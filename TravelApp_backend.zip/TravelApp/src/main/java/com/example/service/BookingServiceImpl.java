package com.example.service;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	import com.example.entity.Booking;
	import com.example.entity.Hotel;
	import com.example.entity.Transport;
	import com.example.entity.LocalTransport;
	import com.example.entity.Users;
	import com.example.error.ResourceNotFoundException;
	import com.example.repository.BookingRepository;

	@Service
	public class BookingServiceImpl implements BookingService {

	    @Autowired
	    private BookingRepository bookingRepository;

	    @Autowired
	    private UsersService userService;

	    @Autowired
	    private HotelService hotelService;

	    @Autowired
	    private TransportService transportService;

	    @Autowired
	    private LocalTransportService localTransportService;

	    @Override
	    public List<Booking> getAllBookings() {
	        return bookingRepository.findAll();
	    }

	    @Override
	    public Booking getBookingById(Long booking_id) {
	        return bookingRepository.findById(booking_id)
	                .orElseThrow(() -> new ResourceNotFoundException("Booking", "booking_id", "booking_id"));
	    }

	    @Override
	    public List<Booking> deleteBooking(Long booking_id) {
	        bookingRepository.deleteById(booking_id);
	        return bookingRepository.findAll();
	    }

	    
	    @Override
	    public Booking addHotelBooking(Booking booking, int userId, long hotel_id, long roomId) {
	        
	        Users user = userService.getUserById(userId);
	        booking.setUser(user);

	      
	        Hotel hotel = hotelService.getHotelById(hotel_id);
	        booking.setHotel(hotel);
	        
	        

	       booking.setUser(user);
	       booking.setHotel(hotel);
	      
	        
	        return bookingRepository.save(booking);
	    }

		@Override
		public Booking addBooking(Booking booking, int userId, long hotel_id, Long transport_id,
				Long localtransport_id) {
			// TODO Auto-generated method stub
			return null;
		}
	}
	    
	    /*@Override
	    public Booking addBooking(Booking booking, int userId, long hotel_id, Long transport_id, Long localtransport_id) {
	        
	        Users user = userService.getUserById(userId);
	        booking.setUser(user);

	      
	        Hotel hotel = hotelService.getHotelById(hotel_id);
	        booking.setHotel(hotel);

	       
	        if (transport_id != null) {
	            Transport transport = transportService.getTransportById(transport_id);
	            booking.setTransport(transport);
	        }

	        
	        if (localtransport_id != null) {
	            LocalTransport localTransport = localTransportService.getLocalTransportById(localtransport_id);
	            booking.setLocalTransport(localTransport);
	        }

	        
	        return bookingRepository.save(booking);
	    }
	}*/