package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Hotel;
import com.example.entity.Room;
import com.example.repository.RoomRepo;
import com.example.error.*;
@Service
public class RoomServiceImpl implements RoomService {
	@Autowired
	private RoomRepo roomReposi;
	
	@Autowired
	private HotelService hotelService;
		@Override
		public Room addRoom(Room room,long hotelId) {
			// TODO Auto-generated method stub
			Hotel hotel = hotelService.getHotelById(hotelId);
			room.setHotel(hotel);
			return roomReposi.save(room);
		}

		@Override
		public List<Room> getAllRooms() {
			// TODO Auto-generated method stub
			return roomReposi.findAll();
		}

		@Override
		public Room getRoomById(Long room_id) {
			// TODO Auto-generated method stub
			return roomReposi.findById(room_id).orElseThrow(()-> new ResourceNotFoundException("Room","room_id","room_id"));
		}

		@Override
		public Room updateRoom(Long room_id, Room room) {
			// TODO Auto-generated method stub
			Room room1 = getRoomById(room_id);
			room1.setRoomNumber(room.getRoomNumber());
			room1.setPrice(room.getPrice());
			room1.setRoomType(room.getRoomType());
			room1.setIsAvailable(room.getIsAvailable());
		
			return roomReposi.save(room1);
		}

		@Override
		public List<Room> deleteRoomById(Long room_id) {
			// TODO Auto-generated method stub
			roomReposi.deleteById(room_id);
			return roomReposi.findAll();
		}

		
		@Override
		public List<Room> getRoomsByHotelId(long hotel_id) {
			// TODO Auto-generated method stub
			return roomReposi.findByHotelHotelId(hotel_id);
		}

		@Override
		public Room updateRoomStatus(Long room_id, Room room) {
			// TODO Auto-generated method stub
			Room room1=getRoomById(room_id);
			room1.setIsAvailable(false);
			return roomReposi.save(room1);
		}

}
