package com.example.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="transport")
public class Transport {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long transport_id;
	 @Column(name="source",length=30,nullable=false)
        private String source;
	 @Column(name="transport_type",length=30,nullable=false)
	    private String transport_type;
	 @Column(name="destination",length=30,nullable=false)
	    private String destination;
	 @Column(name="price",nullable=false)
	    private Double price;
	 @Column(name="date",nullable=false)
	    private String date;
	 @Column(name="time",length=30,nullable=false)
	    private String time;
	 @OneToMany(mappedBy = "transport", cascade = CascadeType.ALL)
     private List<Offer> offers;

		public Long getId() {
			return transport_id;
		}
		public Long getTransport_id() {
			return transport_id;
		}
		public void setTransport_id(Long transport_id) {
			this.transport_id = transport_id;
		}
		public String getSource() {
			return source;
		}
		public void setSource(String source) {
			this.source = source;
		}
		public String getTransport_type() {
			return transport_type;
		}
		public void setTransport_type(String transport_type) {
			this.transport_type = transport_type;
		}
		public String getDestination() {
			return destination;
		}
		public void setDestination(String destination) {
			this.destination = destination;
		}
		public Double getPrice() {
			return price;
		}
		public void setPrice(Double price) {
			this.price = price;
		}
		
		
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
		public String getTime() {
			return time;
		}
		public void setTime(String time) {
			this.time = time;
		}

	   
}
