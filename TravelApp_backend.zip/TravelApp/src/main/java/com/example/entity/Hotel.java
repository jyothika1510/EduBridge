package com.example.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="hotel")
public class Hotel{
	   @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long hotelId;
     @Column(name="hotel_name",length=30,unique=true)
	    private String hotel_name;
     @Column(name="hotel_location",length=30,nullable=false)
    
	    private String hotelLocation;
     @Column(name="hotel_price_per_night",nullable=false)
	    private Double hotel_price_per_night;
     @Column(name="hotel_rating",nullable=false)
	    private Double hotel_rating;
     @Column(name="hotel_review",length=30,nullable=false)
     
	    private String hotel_review;
     @Column(name="petFriendly",length=30,nullable=false)
     private boolean petFriendly;
     
     @OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL)
     private List<LocalTransport> localTransports;

     @OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL)
     private List<Offer> offers;
     @OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL)
     private List<Room> rooms;
	
	public Long getHotelId() {
		return hotelId;
	}
	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}
	public String getHotel_name() {
		return hotel_name;
	}
	public void setHotel_name(String hotel_name) {
		this.hotel_name = hotel_name;
	}
	
	public Double getHotel_price_per_night() {
		return hotel_price_per_night;
	}
	public void setHotel_price_per_night(Double hotel_price_per_night) {
		this.hotel_price_per_night = hotel_price_per_night;
	}
	public Double getHotel_rating() {
		return hotel_rating;
	}
	public void setHotel_rating(Double hotel_rating) {
		this.hotel_rating = hotel_rating;
	}
	public String getHotel_review() {
		return hotel_review;
	}
	public void setHotel_review(String hotel_review) {
		this.hotel_review = hotel_review;
	}
	public boolean isPetFriendly() {
		return petFriendly;
	}
	public String getHotelLocation() {
		return hotelLocation;
	}
	public void setHotelLocation(String hotelLocation) {
		this.hotelLocation = hotelLocation;
	}
	public void setPetFriendly(boolean petFriendly) {
		this.petFriendly = petFriendly;
	}
		
	    
		
	
	
	 

}
		
	    
		
	
	
	 


