package com.example.entity;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Booking {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long booking_id;

	    private String bookingType; // e.g., "Hotel", "LocalTransport"
	    private Date bookingDate;

	    @ManyToOne
	    @JoinColumn(name = "hotel_id", nullable = true)
	    private Hotel hotel;
	    @ManyToOne
	    @JoinColumn(name = "transport_id", nullable = true)
	    private Transport transport;
	    @ManyToOne
	    @JoinColumn(name = "local_transport_id", nullable = true)
	    private LocalTransport localTransport;
		public Long getBooking_id() {
			return booking_id;
		}
		@ManyToOne(fetch = FetchType.LAZY)
	    @JoinColumn(name = "userId", nullable = false)
	    private Users user;

	    

	  

	  public Users getUser() {
	        return user;
	    }

	    public void setUser(Users user) {
	        this.user = user;
	    }

	    public Hotel getHotel() {
	        return hotel;
	    }

	    public void setHotel(Hotel hotel) {
	        this.hotel = hotel;
	    }

	    public Transport getTransport() {
	        return transport;
	    }

	    public void setTransport(Transport transport) {
	        this.transport = transport;
	    }
		public void setBooking_id(Long booking_id) {
			this.booking_id = booking_id;
		}
		public String getBookingType() {
			return bookingType;
		}
		public void setBookingType(String bookingType) {
			this.bookingType = bookingType;
		}
		public Date getBookingDate() {
			return bookingDate;
		}
		public void setBookingDate(Date bookingDate) {
			this.bookingDate = bookingDate;
		}
		
	    
}
