package com.example.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="localtransport")
public class LocalTransport {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long localtransport_id;
    @Column(name="transport_type",length=30,nullable=false)
    
    private String localtransport_type;
    @Column(name="location",nullable=false,length=20)
    private String location;
    @Column(name="price_per_km",nullable=false)
    private Double price_per_km;
    @ManyToOne 
    @JoinColumn(name = "hotel_id")
    private Hotel hotel;
    @OneToMany(mappedBy = "localTransport", cascade = CascadeType.ALL)
    private List<Offer> offers;
	public Long getLocaltransport_id() {
		return localtransport_id;
	}
	public void setLocaltransport_id(Long localtransport_id) {
		this.localtransport_id = localtransport_id;
	}
	public String getLocaltransport_type() {
		return localtransport_type;
	}
	public void setLocaltransport_type(String localtransport_type) {
		this.localtransport_type = localtransport_type;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Double getPrice_per_km() {
		return price_per_km;
	}
	public void setPrice_per_km(Double price_per_km) {
		this.price_per_km = price_per_km;
	}
		
    
}
