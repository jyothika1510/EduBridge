package com.example.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Offer {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long offer_id;

	    private String description;
	    private double discount;

	    @ManyToOne
	    @JoinColumn(name = "hotel_id", nullable = true)
	    private Hotel hotel;
	    
	    @ManyToOne
	    @JoinColumn(name = "transport_id", nullable = true)
	    private Transport transport;
	    
	    @ManyToOne
	    @JoinColumn(name = "localtransport_id", nullable = true)
	    private LocalTransport localTransport;

		public Long getOffer_id() {
			return offer_id;
		}

		public void setOffer_id(Long offer_id) {
			this.offer_id = offer_id;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public double getDiscount() {
			return discount;
		}

		public void setDiscount(double discount) {
			this.discount = discount;
		}
	    
}
